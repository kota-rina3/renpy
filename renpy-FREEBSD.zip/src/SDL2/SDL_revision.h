/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.32.8-0-g98d1f3a45 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.32.8-0-g98d1f3a45"
#endif
